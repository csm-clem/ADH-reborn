const WORKER_RELEASE='0.23.0';
const CACHE=`fretboard-trainer-v${WORKER_RELEASE}:${self.registration.scope}`;
const ASSETS=['./beginner-guide.js','./beginner-guide.css','./services/update-service.js','./debug-mode.js','./bug-report.js','./music-audit.js','./achievement-rules.js','./achievement-data.js','./achievements-ui.js','./achievements.css','./themes.js','./curriculum-rules.js','./interaction.css','./services/audio-service.js','./services/storage-service.js','./services/app-store.js','./services/platform-service.js','./','./index.html','./ui-kit.html','./ui.css','./tokens.css','./components.css','./progress.css','./progress.js','./style.css','./brand.css','./app.js','./release.js','./state.js','./instrument-art.js','./learning-help.js','./tuning.js','./onboarding.js','./onboarding.css','./pilot.js','./pilot-ui.js','./pilot.css','./neck-view.js','./neck.css','./answer-wheel.css','./discovery-feedback.js','./dom-view.js','./demo-rules.js','./reward-music.js','./position-buttons.css','./refinement.css','./core.js','./clock.js','./sound.js','./octave-music.js','./melodies.js','./result.css','./results.js','./result-ui.js','./fonts/jost.ttf','./fonts/open-sans.ttf','./manifest.webmanifest','./instruments/guitar6strings.webp','./instruments/guitar7strings.webp','./instruments/guitar8strings.webp','./instruments/bass4strings.webp','./instruments/bass5strings.webp','./instruments/bass6strings.webp','./icons/icon.svg','./icons/icon-192.png','./icons/icon-512.png','./icons/maskable-512.png'];
self.addEventListener('install',event=>event.waitUntil((async()=>{const pinned=new URL(self.location.href).searchParams.get('release');if(pinned&&pinned!==WORKER_RELEASE)throw new Error('La mise à jour attend votre accord.');const cache=await caches.open(CACHE);await cache.addAll(ASSETS);})()));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>(key.startsWith('adh-reborn-')||key.startsWith('fretboard-trainer-'))&&key.endsWith(`:${self.registration.scope}`)&&key!==CACHE).map(key=>caches.delete(key)))).then(()=>self.clients.claim())));
self.addEventListener('message',event=>{if(event.data?.type==='ACTIVATE_UPDATE')self.skipWaiting();});
self.addEventListener('fetch',event=>{
  if(/\/(?:latest|update)\.json$/.test(new URL(event.request.url).pathname))return;
  if(new URL(event.request.url).pathname.includes('/api/'))return;
  if(event.request.method!=='GET'||new URL(event.request.url).origin!==self.location.origin)return;
  event.respondWith(caches.open(CACHE).then(cache=>cache.match(event.request)).then(cached=>cached||fetch(event.request).catch(error=>{
    if(event.request.mode==='navigate')return caches.match(new URL('./index.html',self.registration.scope));
    throw error;
  })));
});
