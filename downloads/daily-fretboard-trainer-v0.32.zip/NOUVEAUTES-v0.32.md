# Daily Fretboard Trainer v0.32

Les cartes de succès reprennent les cinq finitions choisies après la revue des quinze propositions visuelles.

| Rareté | Finition retenue | Rendu dans la collection |
|---|---|---|
| Commune | **C2 · Papier d’atelier** | Fond papier crème, fibres discrètes dans les marges, cadre cuivre mat. |
| Inhabituelle | **U1 · Aluminium brossé** | Fond aluminium aux nuances vertes, tranche brossée et double filet. |
| Rare | **R3 · Opale bleue** | Fond bleu opalin, cadre dichroïque cyan et lilas, reflets fixes dans l’illustration. |
| Épique | **E3 · Argent nacré** | Fond argenté sur toute la carte, nuances de nacre bleue et mauve, cadre argent. |
| Légendaire | **L2 · Or gravé** | Fond doré sur toute la carte et guillochage gravé dans les marges. |

La même matière habille le recto et le verso. Les fonds et les reflets fixes sont visibles sans survol ; les reflets de l’illustration suivent toujours la souris ou le doigt. Aucun reflet mobile ne passe sur les textes ou les boutons. Les gravures et fibres évitent la zone de lecture centrale.

Les petites mentions utilisent des encres ajustées à la matière pour conserver leur contraste. Les boutons gardent les styles partagés de l’application. Les cartes en cours restent neutres et conservent leur action Essayer en couleur.

Le thème Studio nuit adapte les matières à des fonds sombres. Inclusif-contrasté conserve des teintes mates, des contours francs et les indices de rareté écrits, sans reflets. Papier traduit les finitions en gris. La réduction des animations coupe les reflets mobiles et le retournement animé, tout en conservant les nouvelles matières fixes.

Les titres, illustrations principales, critères, numéros, dates et règles d’obtention ne changent pas. La clé de stockage reste `fretboard-trainer:pilot:stable` ; cette livraison n’introduit pas de migration de données.

## Livraison

Version `0.32.0`, préparée à partir du dépôt disponible en `0.29.0`. Aucune version intermédiaire n’est reconstituée. Le ZIP contient les fichiers de production à transférer par FTP, avec les textures SVG locales et le service worker mis à jour. Les instructions sont dans `LISEZ-MOI.txt`.

Les vérifications du composant et les captures de la vraie application sont conservées dans [v0.32](v0.32/). Le rapport [verification.json](v0.32/verification.json) précise les configurations contrôlées. Les tests Chromium ne remplacent pas un essai sur un téléphone physique.

## Vérifications réalisées

- Vérification de syntaxe JavaScript et 29 fichiers de tests Node réussis ; contrat des boutons partagés et cohérence des versions recontrôlés.
- 59 cartes contrôlées dans les quatre thèmes aux largeurs 320, 390, 768, 1024 et 1440 px : pas de débordement horizontal, boutons d’au moins 44 px et dates dans le cadre.
- Recto/verso et retour du focus vérifiés pour les cinq raretés dans chaque thème, avec défilement des critères longs.
- 380 mesures de contraste sur les pixels des fonds rendus : minimum 4,56:1 pour les textes contrôlés, petits textes compris.
- Gestes tactiles réels Chromium pour les cinq raretés et mode de réduction des animations vérifiés.
- Mise à jour depuis le ZIP v0.29 : refus conservant l’ancienne version, nouvelle proposition au lancement suivant, acceptation et progrès conservés à l’identique.
- ZIP extrait dans un sous-dossier, puis ouverture hors ligne des 59 cartes ; les trois textures sont présentes dans le cache. CRC et identité des fichiers extraits contrôlés.

Le contrôle de l’application locale observe deux réponses 404 pour `latest.json`, manifeste parent facultatif des installations versionnées. Les ressources nécessaires à l’application et aux cartes ne présentent pas d’échec ; un descripteur v0.32 est fourni dans `downloads/latest.json` pour les déploiements qui utilisent ce mode d’annonce.
